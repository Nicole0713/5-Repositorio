package fundacion;

public interface Acciones {
    
    public abstract void donar();
    
}
