package fundacion;

import java.util.ArrayList;
import java.util.Scanner;

public abstract class Donacion implements ManejoDonacion {
    
    Scanner sc = new Scanner(System.in);

    protected String codigo;
    protected Donante donante;
    protected String motivo;

    ArrayList<Donacion> donacion;

    public Donacion(String codigo, Donante donante, String motivo) {
        donacion = new ArrayList();
        this.codigo = codigo;
        this.donante = donante;
        this.motivo = motivo;
    }

    public Donacion() {
        donacion = new ArrayList();
    }

    public Donacion(String codigo) {
        this.codigo = codigo;
        donacion = new ArrayList();
    }

    public ArrayList<Donacion> getDonacion() {
        return donacion;
    }

    public void setDonacion(ArrayList<Donacion> donacion) {
        this.donacion = donacion;
    }

    public String getCodigo() {
        return codigo;
    }

    public Donante getDonante() {
        return donante;
    }

    public String getMotivo() {
        return motivo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public void setDonante(Donante donante) {
        this.donante = donante;
    }

    public void setMotivo(String motivo) {
        this.motivo = motivo;

    }

    @Override
    public void registroDeDonacion(int x) {
        Donante donante1 = null;
        if(x==1) {
            Donante don = new Donante();
            System.out.println("- Ingreso de donación comestible -");
            sc.nextLine();
            Donacion dn = new DonacionComestibles();
            DonacionComestibles dc = (DonacionComestibles) dn;
            System.out.println("Ingrese el codigo:  ");
            String cod = sc.nextLine();
            System.out.println("Ingrese el tipo de comestible:  ");
            String com = sc.nextLine();
            System.out.println("¿Es enlatado?  ");
            boolean en = sc.nextBoolean();
            sc.nextLine();
            System.out.println("Ingrese la cédula del donante: ");
            String ced = sc.nextLine();
            
            //comparar la cedula 
            
            don.registrarDonacion(ced);
           
            
            System.out.println("Ingrese el motivo: ");
            String mot = sc.nextLine();
            dn = new DonacionComestibles(cod, com, en, donante1, mot);
            donacion.add(dn);
            System.out.println("\n \n \n \n");
        } else {
            if (x == 2) {
                System.out.println("- Ingreso de donación económica -");
                sc.nextLine();
                Donacion dn = new DonacionEconomica();
                DonacionEconomica de = (DonacionEconomica) dn;
                System.out.println("Ingrese el monto: ");
                double mont = sc.nextDouble();
                sc.nextLine();
                System.out.println("Ingrese el codigo:  ");
                String cod = sc.nextLine();
                System.out.println("Ingrese la divisa:  ");
                String div = sc.nextLine();
                System.out.println("Ingrese el banco:  ");
                String banc = sc.nextLine();
                //ingresar donante
                Donante don = new Donante();
                System.out.println("Ingrese el motivo: ");
                String mot = sc.nextLine();
                dn = new DonacionEconomica(mont, div, banc, cod, don, mot);
                donacion.add(dn);
                System.out.println("\n \n");
                de.calcularTotal();
            } else {
                if (x == 3) {
                    System.out.println("- Ingreso de donación de juguetes -");
                    sc.nextLine();
                    System.out.println("Ingrese el codigo: ");
                    String cod = sc.nextLine();
                    System.out.println("Ingrese el tipo de juguete: ");
                    String tip = sc.nextLine();
                    System.out.println("Ingrese la cantidad de juguetes: ");
                    int cant = sc.nextInt();
                    Donacion dn = new DonacionJuguetes(cod, tip, cant);
                    donacion.add(dn);
                    System.out.println("\n \n");
                } else {
                    if (x == 4) {
                        MenuPrincipal mp = new MenuPrincipal();
                    } else {
                        System.out.println("Solo puede ingresar del 1 al 4.");
                    }
                }
            }
        }


    }
    
    @Override
    public void mostrarDonacion() {
        Donante don = new Donante();
        int i = 1;
        System.out.println("Existen " + donacion.size() + " donaciones registradas:");
        for (Donacion dn : donacion) {
            System.out.println("Donación " + i + ": ");
            if (dn instanceof DonacionComestibles) {
                DonacionComestibles dc = (DonacionComestibles) dn;
                System.out.println("COMESTIBLE:  " + "Código: " + dc.getCodigo() + "; Tipo: " + dc.getTipodeComestible() + "; Comestible: " + dc.getenlatado() + "; Datos del donante: " + don.getApellidos());
            } else {
                if (dn instanceof DonacionJuguetes) {
                    DonacionJuguetes dj = (DonacionJuguetes) dn;
                    System.out.println("JUGUETE:  " + "Código: " + dj.getCodigo() + "; Tipo: " + dj.getTipo() + "; Cantidad: " + dj.getCantidad()+ "; Datos del donante: " + don.getApellidos());
                } else {
                    if (dn instanceof DonacionEconomica) {
                        DonacionEconomica de = (DonacionEconomica) dn;
                        System.out.println("ECONÓMICA:  " + "Código: " + de.getCodigo() + "; Divisa: " + de.getDivisa() + "; Banco: " + de.getBanco()+ "; Datos del donante: " + don.getApellidos());
                    }
                }
            }
            i++;

        }
    }

}
