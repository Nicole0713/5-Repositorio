package fundacion;

import java.util.Scanner;

public class DonacionJuguetes extends Donacion {

    private String tipo;
    private int cantidad;
    private String juguetes[];
    Scanner sc = new Scanner(System.in);

    public DonacionJuguetes() {
    }

    public DonacionJuguetes(String tipo, int cantidad, String[] juguetes) {
        this.tipo = tipo;
        this.cantidad = cantidad;
        this.juguetes = juguetes;
    }

    public DonacionJuguetes(String codigo, String tipo, int cantidad) {
        super(codigo);
        this.tipo = tipo;
        this.cantidad = cantidad;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public String[] getJuguetes() {
        return juguetes;
    }

    public void setJuguetes(String[] juguetes) {
        this.juguetes = juguetes;
    }


    public void busquedaDonacion() {

    }


    @Override
    public void busquedaDonacion(String cod) {
        for (Donacion dn : this.donacion) {
            if (dn.codigo.equals(cod)) {
                DonacionJuguetes dj = (DonacionJuguetes) dn;
                System.out.println("");
                System.out.println("Donacion Encontrada");
                System.out.println("JUGUETE:  " + "Código: " + dj.getCodigo() + " Tipo de juguete: "
                        + dj.getTipo() + " Cantidad: " + dj.getCantidad());
                System.out.println("");
                break;
            }
        }
    }

}

