package fundacion;

public class FundacionX {

    public static void main(String[] args) {
        
        MenuPrincipal mp = new MenuPrincipal();
        mp.mostrarMenu();
        
        
    }
    
}
