package fundacion;

import java.util.Scanner;

public class DonacionComestibles extends Donacion {

    Scanner sc = new Scanner(System.in);

    private String tipodeComestible;
    private boolean enlatado;

    int iterador;

    public DonacionComestibles() {
    }

    public DonacionComestibles(String codigo, String tipo, boolean enlatado, Donante donante, String motivo) {
        super(codigo, donante, motivo);
        this.tipodeComestible = tipo;
        this.enlatado = enlatado;
    }

    public String getTipodeComestible() {
        return this.tipodeComestible;
    }

    public boolean getenlatado() {
        return this.enlatado;
    }

    public void setTipodeComestible(String tipo) {
        this.tipodeComestible = tipo;
    }

    public void setEnlatado(boolean enlatado) {
        this.enlatado = enlatado;
    }

    @Override
    public void busquedaDonacion(String cod) {

        for (Donacion dn : this.donacion) {
            if (dn.codigo.equals(cod)) {
                dn = new DonacionComestibles();
                DonacionComestibles dc = (DonacionComestibles) dn;
                System.out.println("");
                System.out.println("_Donación Encontrada_");
                System.out.println("COMESTIBLE:  " + "Código: " + dc.getCodigo() + " Tipo de comestible: " + dc.getTipodeComestible()
                        + " Enlatado: " + dc.getenlatado());
                System.out.println("");
                break;
            }
        }
    }

}
