package fundacion;

import java.util.Scanner;

public class DonacionEconomica extends Donacion {

    private double monto;
    private String divisa;
    private String banco;

    Scanner sc = new Scanner(System.in);
    //ArrayList<Donacion> don =new ArrayList<>();

    int iterador;

    public DonacionEconomica() {
    }

    public DonacionEconomica(double monto, String divisa, String banco, String codigo, Donante donante, String motivo) {
        super(codigo, donante, motivo);
        this.monto = monto;
        this.divisa = divisa;
        this.banco = banco;
    }

    public double getMonto() {
        return monto;
    }

    public String getDivisa() {
        return divisa;
    }

    public String getBanco() {
        return banco;
    }

    public void setMonto(double monto) {
        this.monto = monto;
    }

    public void setDivisa(String divisa) {
        this.divisa = divisa;
    }

    public void setBanco(String banco) {
        this.banco = banco;
    }


    @Override
    public void busquedaDonacion(String cod) {
        for (Donacion dn : this.donacion) {
            if (dn.codigo.equals(cod)) {
                dn = new DonacionEconomica();
                DonacionEconomica de = (DonacionEconomica) dn;
                System.out.println("");
                System.out.println("Donacion Encontrada");
                System.out.println("ECONÓMICA:  " + "Código: " + de.getCodigo() + " Tipo de divisa: "
                        + de.getDivisa() + " Banco: " + de.getBanco());
                System.out.println("");
                break;
            }
        }
    }
    
    public void calcularTotal(){
        for (Donacion dn : this.donacion){
            DonacionEconomica de = (DonacionEconomica) dn;
            double total;
            total = de.getMonto();
            System.out.println("El monto total recaudado es: "+total);            
        }

    }

}
